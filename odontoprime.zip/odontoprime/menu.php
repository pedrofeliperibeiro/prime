
<div style="background-color: #ecf0f1; text-align: center;">

  <div class="row">
          <div id="logo" class="span3"> 
              <a href="index.php" > 
                  <div style="display: block; width: 500px;  float: left">
                      <div style="float: left;">
                          <img src="frontend/images/logo/odonto_prime.png"  style="width: 150px;" />
                      </div>
                  </div>
              </a>
          </div>                
          <div class="span9">
  <!-- Social Icons -->
        <ul class="social-icons">
            <li class="facebook"><a href="#">Facebook</a></li>
            <li class="twitter"><a href="#">Twitter</a></li>
            <li class="linkedin"><a href="#">LinkedIn</a></li>
            <li class="googleplus"><a href="#">GooglePlus</a></li>
            <li class="youtube"><a href="#">youtube</a></li>
        </ul>	
    </div>            
  </div>
</div>
<div>        
  <div class="row">
  <div class="span12">
      <div class="select-menu hidden-desktop">
          <select id="selectMenu">
              <option selected value="/">Home</option>
              <option value="#">Pessoa Física</option>
              <option value="/correntista">- Correntista</option>
              <option value="--><!--/plano/servidor">- Servidores Públicos</option>
              <option value="#">Pessoa Jurídica</option>
              <option value="/pme">- 3 a 100 funcionários</option>
              <option value="/pjm">- 101 a 200 funcionários</option>
              <option value="/pj">- Acima de 200 funcionários</option>
              <option value="/vantagem">Clube de Vantagens</option>
              <option value="/noticia">Not&iacute;cias</option>
              <option value="/rede">Rede Credeciada</option>  
              <option value="/pergunta">Perguntas Frequentes</option>
              <option value="/contato">Fale Conosco</option>
          </select>
      </div>
      <ul id="menu" class="visible-desktop">
          <li><a href="index.php">HOME</a></li>
          <li><a href="#">Pessoa Física</a>
              <ul> 
                  <li><a href="correntista.php">Correntistas</a></li>
  <!--                    <li><a href="--><!--/plano/servidor">Servidores Públicos</a></li>-->
              </ul>
          </li>
          <li>
              <a href="#">Pessoa Jurídica</a>
              <ul> 
                  <li><a href="pme.php">3 a 100 funcionários</a></li>
                  <li><a href="pjm.php">101 a 200 funcionários</a></li>
                  <li><a href="pj.php">Acima de 200 funcionários</a></li>
              </ul>
          </li>
          <li><a href="rede.php">Rede Credeciada</a></li>  
          <li><a href="contato.php">Fale Conosco</a></li> 
      </ul>
  </div>
</div>