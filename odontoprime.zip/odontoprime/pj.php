<!DOCTYPE HTML>
<html lang="pt-BR">
    
<head>
        <title>Odontoprime</title>
        <meta charset="UTF-8">
        <!--<meta charset="ISO-8859-1">-->
        <!--<meta http-equiv="X-UA-Compatible" content="IE=8" />-->
        <!--<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />-->
        <!--<meta http-equiv="X-UA-Compatible" content="chrome=1" />-->
        <!--<meta http-equiv="X-UA-Compatible" content="IE=4EDGE" />-->
        <link rel="stylesheet" href="frontend/style.css" />
        <link rel="stylesheet" href="frontend/skins/red-blue/blue.css" id="colors" /> 
        <link rel="icon" href="favicon.html" type="image/x-icon"/>
        <link rel="shortcut icon" href="frontend/favicon.html" type="image/x-icon"/>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.css" />
        <link rel="stylesheet" href="frontend/css/switcher.css">  
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
        <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.3.5/css/swiper.min.css'>
        <link rel="stylesheet" href="frontend/css/slider_odonto.css">

        <!--switcher and-->
    </head>
    <body>
        <div id="wrapper">
            <header id="header" class="container-fluid">
    <div class="header-bg">
        <div class="container">
            <div class="decoration dec-left visible-desktop"></div>
            <div class="decoration dec-right visible-desktop"></div>	  
            <?php include('menu.php'); ?>
        </div>
    </div>
</header>
<section id="content" class="container-fluid">
    <div class="container">
        <div id="headline-page">
            <h1>Solicitaç&atilde;o de Proposta</h1>
            
        </div>
        <div class="span12">
            <div class="thumbnail"><img alt="" src="frontend/images/gallery/gempresa.jpg"></div>
            <p>
                O odontoprime leva para sua empresa muito mais que saúde financeira. Com o Odontoprime a produtividade aumenta, é o sorriso do seu colaborador refletido na satisfaç&atilde;o do cliente.
            </p>
        </div>
        <div class="row">
                            <div class="span12">
                    <div class="title"><h2>Dados da Empresa</h2></div>
                    <div class="row">
                        <div class="span6">
                            <div class="form-padding">
                                <label  for="f4">Você é funcion&aacute;rio odontoprime? :</label>
                                <input type="checkbox" required="" name="cd_odontoprime" id="f4" title="Marque este campo se você é um funcionário odontoprime fazendo uma venda!" class="form-inline cd_odontoprime" value="1" /> Sim	
                                <br>
                                <br>
                            </div>
                        </div>
                    </div>
                    <form id="ajax-contact-form" action="http://www.odontoprimeodonto.com/pj/orcamento" method="POST">
                        <div class="row" id="funcionario">
                            <div class="title"><h4>Dados Funcion&aacute;rio odontoprime</h4></div>
                            <div class="span3">
                                <div class="form-padding">
                                    <label for="f4">Matricula :</label>
                                    <input type="text" name="nu_matricula" required="" id="f4" class="form-text nu_matricula" value="" size="40"/>		
                                </div>
                            </div>
                            <div class="span3">
                                <div class="form-padding">
                                    <label for="f4">Nome Funcion&aacute;rio :</label>
                                    <input type="text" disabled="" name="nm_angariador" id="f4 " class="form-text nm_angariador" value="" size="40"/>		
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="span6">
                                <div class="form-padding">
                                    <label for="f1">Raz&atilde;o Social</label>
                                    <input type="text" required="required" name="nm_razao_social" id="f1" class="form-text" value=""/>
                                </div>
                            </div>
                            <div class="span6">
                                <div class="form-padding">
                                    <label for="f1">Nome Fantasia</label>
                                    <input type="text" required="required" name="nm_nome_fantasia" id="f1" class="form-text" value=""/>
                                </div>
                            </div>

                            <div class="span6">
                                <div class="form-padding">
                                    <label for="f4">CNPJ:</label>
                                    <input type="text" name="nu_cnpj" required="required" id="f4" class="form-text nu_cnpj" value="" />		
                                </div>
                            </div>
                            <div class="span6">
                                <div class="form-padding">
                                    <label for="f4">Inscriç&atilde;o Estadual:</label>
                                    <input type="text" name="nu_inscricao_estadual" required="required" id="f4 nu_incricao_estadual" class="form-text" value="" />		
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="span3">
                                <div class="form-padding">
                                    <label for="f4">CEP :</label>
                                    <input type="text" name="nu_cep_endereco" id="f4 number" required="required" class="form-text nu_cep_endereco" value="" size="40"/>		
                                </div>
                            </div>
                            <div class="span7">
                                <div class="form-padding">
                                    <label for="f4">Endereço:</label>
                                    <input type="text" name="ds_endereco_endereco_" id="f4" class="form-text" value=""/>		
                                </div>
                            </div>
                            <div class="span2">
                                <div class="form-padding">
                                    <label for="f4">Numero:</label>
                                    <input type="text" name="nu_numero_endereco_" id="f4" class="form-text" value="" />		
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="span3">
                                <div class="form-padding">
                                    <label for="f4">Complemento:</label>
                                    <input type="text" name="ds_complemento_endereco_" id="f4" class="form-text" value=""/>		
                                </div>
                            </div>
                            <div class="span4">
                                <div class="form-padding">
                                    <label for="f4">Bairro:</label>
                                    <input type="text" required="required" name="nm_bairro_endereco_" id="f4" class="form-text" value=""/>		
                                </div>
                            </div>
                            <div class="span3">
                                <div class="form-padding">
                                    <label for="f4">Cidade:</label>
                                    <input type="text" required="required" name="nm_cidade_endereco_" id="f4" class="form-text" value="" />		
                                </div>
                            </div>
                            <div class="span2">
                                <div class="form-padding">
                                    <label for="f4">UF</label>
                                    <select required="required" class="form-text" name="nm_uf_endereco_">
                                        <option value="">Selecione...</option>
                                        <option value="AC">AC</option>
                                        <option value="AL">AL</option>
                                        <option value="AM">AM</option>
                                        <option value="AP">AP</option>
                                        <option value="BA">BA</option>
                                        <option value="CE">CE</option>
                                        <option value="DF">DF</option>
                                        <option value="ES">ES</option>
                                        <option value="GO">GO</option>
                                        <option value="MA">MA</option>
                                        <option value="MG">MG</option>
                                        <option value="MS">MS</option>
                                        <option value="MT">MT</option>
                                        <option value="PA">PA</option>
                                        <option value="PB">PB</option>
                                        <option value="PE">PE</option>
                                        <option value="PI">PI</option>
                                        <option value="PR">PR</option>
                                        <option value="RJ">RJ</option>
                                        <option value="RN">RN</option>
                                        <option value="RO">RO</option>
                                        <option value="RR">RR</option>
                                        <option value="RS">RS</option>
                                        <option value="SC">SC</option>
                                        <option value="SE">SE</option>
                                        <option value="SP">SP</option>
                                        <option value="TO">TO</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="span4">
                                <div class="form-padding">
                                    <label for="f4">Nº de Funcionários:</label>
                                    <input type="text" required="required" name="nu_qtd_funcionarios" id="f4 number" class="form-text" value="" size="40"/>		
                                </div>
                            </div>
                            <div class="span4">
                                <div class="form-padding">
                                    <label for="f4">Nome do Responsável:</label>
                                    <input type="text" required="required" name="nm_responsavel" id="f4" class="form-text" value="" size="40"/>		
                                </div>
                            </div>
                            <div class="span3">
                                <div class="form-padding">
                                    <label for="f4">Email :</label>
                                    <input type="email" required="required" name="ds_email" id="f4" class="form-text" value="" size="40"/>		
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="span3">
                                <div class="form-padding">
                                    <label for="f4">Telefone :</label>
                                    <input type="text" required="required" name="nu_telefone" id="f4 nu_telefone" class="form-text" value="" size="40"/>		
                                </div>
                            </div>
                            <div class="span3">
                                <div class="form-padding">
                                    <label for="f4">Celular :</label>
                                    <input type="text" name="nu_celular" id="f4 nu_telefone" class="form-text" value="" size="40"/>		
                                </div>
                            </div>
                            <div class="span3">
                                <div class="form-padding">
                                    <label for="f4">Fax:</label>
                                    <input type="text" name="nu_fax" id="f4 nu_telefone" class="form-text" value="" size="40"/>		
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <span class="span6">
                                <input class="button large s1" type="submit" value="Enviar"> 
                                <!--<a class="button large s1" href="javascript:;">Avançar Para o Passo 2</a>-->
                            </span>
                        </div>

                    </form>
                    <div id="form-message"></div>
                </div>

                    </div>
    </div>
</section>
<?php include('footer.php'); ?>

  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
  <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
  <script src="frontend/js/bootstrap.min.js"></script>
  <!--<script src="/frontend/js/json.js"></script>-->
  <script src="frontend/js/jquery.color.js"></script>
  <!--[if IE]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
  <script src="frontend/js/jquery-easing-1.3.js" type="text/javascript"></script>
  <script src="frontend/js/layerslider.kreaturamedia.jquery.js" type="text/javascript"></script>
  <!--<script src="//cdnjs.cloudflare.com/ajax/libs/json3/3.3.2/json3.min.js"></script>-->
  <script src="frontend/js/custom.js"></script>
  <!--switcher-->

  <script src="frontend/js/jquery.cookie.js"></script>

  <script src="frontend/js/switcher.js"></script>
  <script src="frontend/js/jquery.maskedinput.js"></script>
  <script src="frontend/js/valida.js"></script>
  <!--switcher and-->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.3.5/js/swiper.min.js'></script>
  <script type="text/javascript">
    function carregaPage(){

    }

  </script>
    </body>

</html>
