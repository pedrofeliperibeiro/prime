<!DOCTYPE HTML>
<html lang="pt-BR">

<meta http-equiv="content-type" content="text/html;charset=pt_BR.ISO-8859-1" /><!-- /Added by HTTrack -->
<head>
  <title> OdontoPrime</title>
  <meta charset="UTF-8">
  <!--<meta charset="ISO-8859-1">-->
  <!--<meta http-equiv="X-UA-Compatible" content="IE=8" />-->
  <!--<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />-->
  <!--<meta http-equiv="X-UA-Compatible" content="chrome=1" />-->
  <!--<meta http-equiv="X-UA-Compatible" content="IE=4EDGE" />-->
   <link rel="stylesheet" href="frontend/style.css" />
  <link rel="stylesheet" href="frontend/skins/red-blue/blue.css" id="colors" /> 
  <link rel="icon" href="favicon.html" type="image/x-icon"/>
  <link rel="shortcut icon" href="frontend/favicon.html" type="image/x-icon"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.css" />
  <link rel="stylesheet" href="frontend/css/switcher.css">  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.3.5/css/swiper.min.css'>
  <link rel="stylesheet" href="frontend/css/slider_odonto.css">  

  <!--switcher and-->
</head>
<body>
  <div id="wrapper">
    <header id="header" class="container-fluid">
      <div class="header-bg">
        <div class="container">
          <div class="decoration dec-left visible-desktop"></div>
          <div class="decoration dec-right visible-desktop"></div>	  
          <?php include('menu.php'); ?>
          </div>
        </header>
        <section id="content" class="container-fluid">
          <div class="container">
            <div id="headline-page">
              <h1>Pessoa Física</h1>
              
            </div>
            <div class="span12">
              <div class="thumbnail"><img alt="" src="frontend/images/family.jpg"></div>
              <p>
                A OdontoPrime leva para sua empresa muito mais que saúde financeira. Com A OdontoPrime ODONTO a produtividade aumenta, é o sorriso do seu colaborador refletido na satisfaç&atilde;o do cliente.
              </p>
            </div>
            <div class="row">
              <div class="span8">
                <div class="title"><h2>Planos exclusivo para empresas</h2></div>
                <div class="pricecolumn">
                  <ul class="col odd">
                    <li class="title-td"><h3>Plano OdontoPrime ODONTO Plus com Ortodontia sem carência</h3></li>
                    <li class="price-td">
                      <span class="number">
                        <span class="dollar">R$</span>125<span class="cents">50</span><span class="time">/mês</span>
                      </span>
                    </li>
                    <li class="button-td"><a class="button-price" href="Pessoa Física/contrate-Pessoa Física/produto/12.html">Contrate agora</a></li>
                  </ul>	
                </div>
                <div class="pricecolumn">
                  <ul class="col odd">
                    <li class="title-td"><h3>Plano: Pessoa Física Odontoclínico 03 a 100 funcionários</h3></li>
                    <li class="price-td">
                      <span class="number">
                        <span class="dollar">R$</span>17<span class="cents">90</span><span class="time">/mês</span>
                      </span>
                    </li>
                    <li><p>24Hs p/ Urgência/emergência (após compensação da 1ª mensalidade)</p>
                    </li>
                    <li><p>Ampla rede credenciada em todo país</p>
                    </li>
                    <li><p>Sem Carência para Procedimentos Clínicos</p>
                    </li>
                    <li><p>Sem pr&eacute;-aprova&ccedil;&atilde;o, o tratamento &eacute; iniciado na primeira consulta</p>
                    </li>
                    <li><ul>
                     <li>Atendimento em consult&oacute;rio particular com hora marcada</li>
                   </ul>
                 </li>
                 <li><p>Informa&ccedil;&otilde;es e servi&ccedil;os em tempo real pela internet no portal odontoprime</p>
                 </li>
                 <li class="button-td"><a class="button-price" href="Pessoa Física/contrate-Pessoa Física/produto/11.html">Contrate agora</a></li>
               </ul>	
             </div>
           </div>
           <div class="span3 span3-correntista">
            <div class="title"><h2>Voc&ecirc; sabia?</h2></div>
            <p>Que como a administraç&atilde;o de contratos coletivos tem um custo menor para a operadora, essa reduç&atilde;o de custo é repassada para a empresa, ou seja, o valor mensal do plano odontológico para as empresas é menor que para os planos individuais.</p>
            <p>Que um colaborador com saúde bucal e auto-estima elevada é mais comprometido e produtivo para a empresa. Além disso, existem vários estudos que comprovam a diminuiç&atilde;o do absenteísmo dos colaboradores em empresas que oferecem plano odontológico.<br>
              <a class="" href="sabia/empresa.html">Saiba mais</a>
            </p>
          </div>
        </div>
      </div>
    </section>        
  </div>
  <?php include('footer.php'); ?>

  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
  <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
  <script src="frontend/js/bootstrap.min.js"></script>
  <!--<script src="/frontend/js/json.js"></script>-->
  <script src="frontend/js/jquery.color.js"></script>
  <!--[if IE]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
  <script src="frontend/js/jquery-easing-1.3.js" type="text/javascript"></script>
  <script src="frontend/js/layerslider.kreaturamedia.jquery.js" type="text/javascript"></script>
  <!--<script src="//cdnjs.cloudflare.com/ajax/libs/json3/3.3.2/json3.min.js"></script>-->
  <script src="frontend/js/custom.js"></script>
  <!--switcher-->

  <script src="frontend/js/jquery.cookie.js"></script>

  <script src="frontend/js/switcher.js"></script>
  <script src="frontend/js/jquery.maskedinput.js"></script>
  <script src="frontend/js/valida.js"></script>
  <!--switcher and-->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.3.5/js/swiper.min.js'></script>
  <script type="text/javascript">
    function carregaPage(){

    }

  </script>


</body>
</html>
</html>
