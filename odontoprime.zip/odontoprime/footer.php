<footer id="footer" class="container-fluid">
<div class="container">
    <section class="row">
        <article class="span3">
            <h3 class="title">Endereço</h3>
            <p>

            </p>
            <div class="link">
                Site: <a href="http://www.odontoprime.com.br/" target="_black">www.odontoprime.com.br</a><br>
                E-mail: <a href="mailto:contato@odontoprime.com.br<">contato@odontoprime.com.br</a>
            </div>
            <ul class="social-icons">
                <li class="facebook"><a href="#">Facebook</a></li>
                <li class="twitter"><a href="#">Twitter</a></li>
                <li class="linkedin"><a href="#">LinkedIn</a></li>
                <li class="googleplus"><a href="#">GooglePlus</a></li>
                <li class="youtube"><a href="#">youtube</a></li>
            </ul>	
        </article>
        <article class="span3 navblock">
            <h3 class="title">Menu</h3>
            <ul> 
                <li><a href="indique.html">Indique seu Dentista</a></li>
            </ul>
        </article>
        <article class="span3 ">
           
        </article>
        <article class="span3">
            <div>
              <img src="frontend/images/logo/odonto_prime.png">
            </div>
            <p>
                Eficiencia, Praticidade, Solidez, Qualidade, Credibilidade.
                O OdontoPrime  alcançou tudo isso para você e sua empresa na parceria com a odontoprime.

            </p>
            <a href="http://www.ans.gov.br/" target="_black">
                <img src="frontend/images/ans.jpg" title="ANS - Agência Nacional de Saúde Suplementar | A agência reguladora de planos de saúde do Brasil" alt="ANS - Agência Nacional de Saúde Suplementar | A agência reguladora de planos de saúde do Brasil"/>
            </a>
        </article>
    </section>
    <div class="back-top up"><a href="#top"></a></div>
</div>
</footer>
  <footer class="footer-line container-fluid">
      <div class="container">
          <div class="row-fluid">
              <div class="span8 alignleft"><a href="http://www.odontoprime.com.br/" target="_black">Portal odontoprime</a> Copyright © 1999 - 2018 odontoprime LTDA</div>
              <div class="span4 alignright hidden-phone"><a href="http://wquest.com.br/" alt="W.Quest - Agência de Comunicação" title="W.Quest - Agência de Comunicação" target="_blank">W.Quest - Agência de Comunicação</a><a href="#top" class="top up" style="display: inline;">Top</a></div>
          </div>
      </div>
  </footer>