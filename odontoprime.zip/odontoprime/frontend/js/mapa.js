var geocoder;
var map;
var marker;
var info;


function initialize() {
    var latlng = new google.maps.LatLng(-15.802851, -47.881859);
    var options = {
        zoom: 5,
        center: latlng,
        mapTypeId: google.maps.MapTypeId.ROADMAP
    };
    
    map = new google.maps.Map(document.getElementById("mapa"), options);
    
    geocoder = new google.maps.Geocoder();
    
    marker = new google.maps.Marker({
        map: map,
        draggable: true,
    });
    
    marker.setPosition(latlng);
}

$(document).ready(function () {
    
    initialize();
    
    $(".btnEndereco").click(function() {
        //        $('#mapa').slideDown();
        var endereco = $(this).attr('value');
        var dados = $(this).attr('info');
        info = '<div style="width:1100" id="content">'+
                    '<div style="width: 250px;" id="bodyContent">'+
                        '<p>'+dados+'</p>'+
                    '</div>'+
                '</div>';
            
        carregarNoMapa(endereco);
        $('html, body').animate({scrollTop: 800}, 800);
    })
    
    function carregarNoMapa(endereco) {
        geocoder.geocode({
            'address': endereco + ', Brasil', 
            'region': 'BR'
        }, function (results, status) {
            if (status == google.maps.GeocoderStatus.OK) {
                if (results[0]) {
                    var latitude = results[0].geometry.location.lat();
                    var longitude = results[0].geometry.location.lng();
                    var location = new google.maps.LatLng(latitude, longitude);
                    map.setCenter(location);
                    map.setZoom(16);
                    marker = new google.maps.Marker({
                        map: map,
                        draggable: true,
                        position: location,
                    });
                    var infowindow = new google.maps.InfoWindow({
                        content:info
                    });
//                    google.maps.event.addListener(marker, 'click', function() {
//                        infowindow.open(map,marker);
//                    });
                    infowindow.open(map, marker);  
                }
            }
        })
    }
    
    
    google.maps.event.addListener(marker, 'drag', function () {
        geocoder.geocode({
            'latLng': marker.getPosition()
        }, function (results, status) {
            if (status == google.maps.GeocoderStatus.OK) {
                if (results[0]) {  
                    $('#txtEndereco').val(results[0].formatted_address);
                    $('#txtLatitude').val(marker.getPosition().lat());
                    $('#txtLongitude').val(marker.getPosition().lng());
                }
            }
        });
    });
    
    $("#txtEndereco").autocomplete({
        source: function (request, response) {
            geocoder.geocode({
                'address': request.term + ', Brasil', 
                'region': 'BR'
            }, function (results, status) {
                response($.map(results, function (item) {
                    return {
                        label: item.formatted_address,
                        value: item.formatted_address,
                        latitude: item.geometry.location.lat(),
                        longitude: item.geometry.location.lng()
                    }
                }));
            })
        },
        select: function (event, ui) {
            $("#txtLatitude").val(ui.item.latitude);
            $("#txtLongitude").val(ui.item.longitude);
            var location = new google.maps.LatLng(ui.item.latitude, ui.item.longitude);
            marker.setPosition(location);
            map.setCenter(location);
            map.setZoom(16);
        }
    });
    
    $("form").submit(function(event) {
        event.preventDefault();
        
        var endereco = $("#txtEndereco").val();
        var latitude = $("#txtLatitude").val();
        var longitude = $("#txtLongitude").val();
        
        alert("Endereço: " + endereco + "\nLatitude: " + latitude + "\nLongitude: " + longitude);
    });

});