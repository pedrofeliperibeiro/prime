$(document).ready(function () {
    // Menu
    $("#menu li").hover(function () {
        $('ul:first', this).slideDown('700');
    }, function () {
        $('ul:first', this).stop().slideUp('700');
    });
    // Clear search form
    $.fn.autoClear = function () {
        $(this).each(function () {
            $(this).data("autoclear", $(this).attr("value"));
        });
        $(this)
                .bind('focus', function () {
                    if ($(this).attr("value") == $(this).data("autoclear")) {
                        $(this).attr("value", "");
                    }
                })
                .bind('blur', function () {
                    if ($(this).attr("value") == "") {
                        $(this).attr("value", $(this).data("autoclear"));
                    }
                });
        return $(this);
    }
    $('.search-text-box,.rss-text-box').autoClear();

    // Buttom up
    $(".up").hide();
    $(function () {
        $(window).scroll(function () {
            if ($(this).scrollTop() > 50) {
                $('.up').fadeIn();
            } else {
                $('.up').fadeOut();
            }
        });
        $('.up').click(function () {
            $('body,html').animate({
                scrollTop: 0
            }, 800);
            return false;
        });
    });

    // Social icons
    $(".social-icons a").hover(function () {
        $(this).stop().animate({
            'top': '0'
        }, 300);
    }, function () {
        $(this).stop().animate({
            'top': '-24px'
        }, 300);
    });

    // Service Icon Option	
    $(".link-block").hover(function () {
        $('.move-bg-icon', this).css("top", "-100px");
        $('h2.move-item', this).css("left", "-100px");
        $('p.move-item', this).css("bottom", "-100px");
        $('.move-bg-icon', this).stop().animate({
            'top': '0'
        }, 300);
        $('h2.move-item', this).stop().animate({
            'left': '0'
        }, 300);
        $('p.move-item', this).stop().animate({
            'bottom': '0'
        }, 300);
    }, function () {
    });

    // Awards
    $(".award").hover(function () {
        $(this).stop().animate({
            'opacity': '1'
        }, 500);
    }, function () {
        $(this).stop().animate({
            'opacity': '0.5'
        }, 500);
    });

    // Bootstrap Accordion
    $('.accordion-toggle').append($('<div class="marker"></div>'));
    $('.accordion').on('show', function (e) {
        $(e.target).prev('.accordion-heading').find('.accordion-toggle').addClass('target');
    });
    $('.accordion').on('hide', function (e) {
        $(this).find('.accordion-toggle').not($(e.target)).removeClass('target');
    });

    // Bootstrap Tabs
    $('.tab-pane').append($('<div class="bottom-pattern-line"></div><div class="bottom-pattern-right"></div>'));

    // Meet Our Doctors
    $(".link-img-bg").hover(function () {
        $(this).stop().animate({
            'opacity': '1'
        }, 500);
    }, function () {
        $(this).stop().animate({
            'opacity': '0'
        }, 500);
    });

    // Price button
    $(".button-price").hover(function () {
        var obj = $(this).parent().parent().parent();
        obj.find('h3').stop().addClass("active", 500);
        obj.find('.price-td').stop().addClass("active", 500);
        obj.find('.dollar,.cents,.time').stop().addClass("active", 500);
        obj.find('.number').stop().addClass("active", 500);
        $(this).stop().addClass("active", 500);
    }, function () {
        var obj = $(this).parent().parent().parent();
        obj.find('h3').stop().removeClass("active", 200);
        obj.find('.price-td').stop().removeClass("active", 200);
        obj.find('.dollar,.cents,.time').stop().removeClass("active", 200);
        obj.find('.number').stop().removeClass("active", 200);
        $(this).stop().removeClass("active", 200);
    });

    // Table odd	
    $(".column ul.odd").each(function (indx, element) {
        $("li:odd", this).addClass("row-odd");
    });

    // Carousel //
    $('.review-slider').carousel({
        interval: false,
        pause: 'hover'
    });
    is_carousel_working = false;

    //Next Item
    $('.review-slider .next-slide').on('click', function () {
        if (!is_carousel_working) {
            is_carousel_working = true;
            var obj = $(this).parent('.review-slider');
            var active_item = obj.find('.active');
            active_item.find('.md').fadeOut(150);
            var next_item = active_item.next('.item')
            if (next_item.length) {
                slider_bq_h = next_item.height();
                next_item.find('.blockquote').css("height", active_item.find('.blockquote').height() - 15);
            }
            else {
                var first_item = obj.find('.item:first-child');
                slider_bq_h = first_item.height();
                first_item.find('.blockquote').css("height", active_item.find('.blockquote').height() - 15);
            }
            obj.carousel('next');
        }
        return false;
    });

    //Prev Item
    $('.review-slider .prew-slide').on('click', function () {
        if (!is_carousel_working) {
            is_carousel_working = true;
            var obj = $(this).parent('.review-slider');
            var active_item = obj.find('.active');
            active_item.find('.md').fadeOut(150);
            var next_item = active_item.prev('.item')
            if (next_item.length) {
                slider_bq_h = next_item.height();
                next_item.find('.blockquote').css("height", active_item.find('.blockquote').height() - 15);
            }
            else {
                var first_item = obj.find('.item:last-child');
                slider_bq_h = first_item.height();
                first_item.find('.blockquote').css("height", active_item.find('.blockquote').height() - 15);
            }
            obj.carousel('prev');
        }
        return false;
    });

    $(".review-slider").on('slid', function () {
        is_carousel_working = false;
        var obj = $(this);
        obj.find('.active .blockquote').animate({
            height: slider_bq_h - 15
        }, 350);
        obj.find('.blockquote-line').animate({
            height: slider_bq_h + 50
        }, 100, function () {
            obj.find('.active .md').fadeIn(300);
        });
    });
    $(".review-slider").each(function (index, el) {
        var active_item = $(el).find('.active');
        active_item.find('.md').css("display", "block");
        var h = active_item.height();
        active_item.find('.blockquote').css("height", h - 15);
        $(el).find('.blockquote-line').css("height", h + 50);
    });

    // select menu
    $('#selectMenu').change(function () {
        var href = '';
        $('option:selected', this).each(function () {
            href = $(this).attr('value');
            window.location.href = href;
        });
        ye
    });

    // timer
    $(function () {
        var austDay = new Date();
        austDay = new Date(austDay.getFullYear(), austDay.getMonth() + 1, 26);// (2015,01,01)
        if ($("div").is("#countdown")) {
            $('#countdown').countdown({
                until: austDay
            });
            $('#year').text(austDay.getFullYear());
        }
    });

    // layerslider
    $('#layerslider').layerSlider({
        autoStart: true,
        hoverPrevNext: false,
        animateFirstLayer: false,
        thumbnailNavigation: false
    });

    $(function () {
        $('#dependenteForm').hide();
        $('#tableDepedentes').hide();
        $('#funcionario').hide();
        $('#termo').hide();
    });

    $('#incluirDependentes').on('click', function () {
        $('#incluirDependentes').hide();
        $('#dependenteForm').show();
        $('#tableDepedentes').show();
    });
    $('#termoLink').on('click', function () {
        $('#termo').slideDown('slow');
    });

    //Deleta dependente
    $(".deletaDependente").click(function (evented) {

        var element = $(this);
        var id = $(this).attr("id");
        /* Get Confirmation */
        if (confirm('Deseja excluir permanentemente esse dependente?'))
        {
            /* Hide the deleted row with fadeout effect */
            element.parent().parent().eq(0).fadeOut("slow");
            $.post(url, {
                "id": id
            }, function () {
            });

            alert('Dependente excluido com sucesso!');
        }
        return false;

    });

    $('.cd_brb').on('click', function () {
        if ($("input[name='cd_brb']").is(":checked") == true) {
            $('#funcionario').slideDown();
        } else {
            $('#funcionario').slideUp();
        }
    });

    $('.trvavenda').click(function () {
        if ($('.nu_codigo').val() === '') {
            $('#funcionario').slideDown();
        }
    })

    $('.nu_codigo').blur(function () {
        var matricula = $(this).val().replace('______', '');

        if (matricula) {
            $.ajax({
                url: urlPromotor,
                type: "post",
                data: {
                    matricula: matricula
                },
                dataType: 'json',
                error: function (a, b) {
                },
                success: function (retorno) {
                    if (retorno != 'false') {
                        $('.nm_promotor').val(retorno);
                    } else {
                        $('.nm_promotor').val('');
                        $('.nu_codigo').val('');
                        $('.nu_codigo').focus();
                        alert('Código de promotor incorreto, favor digite um código válido');
                    }
                }
            });
        }
    });

    $('.nu_angariador').blur(function () {
        var matricula = $(this).val().replace('______', '');
        if (matricula) {
            $.ajax({
                url: urlAngariador,
                type: "post",
                data: {
                    matricula: matricula
                },
                dataType: 'json',
                error: function (a, b) {
                },
                success: function (retorno) {
                    if (retorno != 'false') {
                        $('.nm_angariador').val(retorno);
                    } else {
                        $('.nu_angariador').val('');
                        $('.nu_angariador').focus();
                        alert('Código de Angariador incorreto, favor digite um código válido');
                    }
                }
            });
        }
    });

    $('.nu_equipe').blur(function () {
        var matricula = $(this).val().replace('______', '');
        if (matricula) {
            $.ajax({
                url: urlEquipe,
                type: "post",
                data: {
                    matricula: matricula
                },
                dataType: 'json',
                error: function (a, b) {
                },
                success: function (retorno) {
                    if (retorno != 'false') {
                        $('.nm_equipe').val(retorno);
                        console.log(retorno);
                    } else {
                        $('.nm_equipe').val('');
                        $('.nu_equipe').val('');
                        $('.nu_equipe').focus();
                        alert('Código de Equipe incorreto, favor digite um código válido');
                    }
                }
            });
        }
    });

    $('.nu_agenciaBrb').blur(function () {
        var matricula = $(this).val().replace('____', '');
        if (matricula) {
            $.ajax({
                url: urlAgencia,
                type: "post",
                data: {
                    matricula: matricula
                },
                dataType: 'json',
                error: function (a, b) {
                },
                success: function (retorno) {
                    if (retorno != 'false') {
                        $('.nm_agencia').val(retorno);
                    } else {
                        $('.nu_agenciaBrb').val('');
                        $('.nu_agenciaBrb').focus();
                        alert('Código de Agência incorreto, favor digite um código válido');
                    }
                }
            });
        }
    });

    function processData(data) {
        console.log(data);
    }


    $('#nm_uf').change(function () {
        var nm_uf = $(this).val();
        $.ajax({
            url: url,
            type: "post",
            data: {
                nm_uf: nm_uf
            },
            dataType: 'json',
            //            contentType: "text/json; charset=utf-8",
            //            crossDomain: true,
            error: function (a, b) {
                console.log(a);
                console.log(b)
                //console.log("ERRO")
            },
            success: function (all) {
                var data = all.all;
                var op = "<option value=''>Selecione uma cidade</option>";
                for (var i in data) {
                    var ci = data[i].replace(/[ ]+/, '-');
                    op += "<option value=" + ci + ">" + data[i] + "</option>";
                }
                $('.tx_cidade').html(op);
                $('.tx_cidadeDiv').slideDown();
            }
        });
    });

    $('#tx_cidade').change(function () {
        var nm_cidade = $(this).val();

        $.ajax({
            url: url,
            type: "post",
            data: {
                nm_cidade: nm_cidade
            },
            dataType: 'json',
            success: function (all) {

                var data = all.all;
                var op = "<option value=''>Selecione um bairro</option>";
                for (var i in data) {
                    var ba = data[i].replace(/[ ]+/, '-');
                    $('.tx_espeDiv').slideDown();
                    op += "<option value=" + ba + ">" + data[i] + "</option>";
                }
                $('.tx_bairro').html(op);
                $('.tx_bairroDiv').slideDown();
                $('.tx_espeDiv').slideDown();
            }
        });
    });


    $('#pesquisar').click(function () {
        var uf = $('#nm_uf').val();
        var cidade = $('#tx_cidade').val();
        var bairro = $('#tx_bairro').val();
        var espe = $('#tx_espe').val();
        $.ajax({
            url: consulta,
            type: "post",
            data: {
                uf: uf,
                cidade: cidade,
                bairro: bairro,
                espe: espe
            },
            dataType: 'html',
            success: function (all) {
                $('#result').html(all)
                $('html, body').animate({
                    scrollTop: 1000
                }, 500);
            }
        });
    });
});

function teste(teste) {
    alert(teste);
}