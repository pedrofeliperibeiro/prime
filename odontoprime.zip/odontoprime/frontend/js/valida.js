$(document).ready(function () {

    $(function () {
        //$.mask.definitions['~'] = "[+-]";
        $(".nu_cnpj").mask("99.999.999/9999-99");
        $(".nu_cpf").mask("999.999.999-99");
        $(".nu_cpfDep").mask("999.999.999-99");
        $(".dt_nasc").mask("99/99/9999");
        $(".dt_nasc2").mask("99/99/9999");
        $(".dt_mes").mask("99/9999");
        $(".nu_cep_endereco").mask("99.999-999");
        $(".nu_cep").mask("99.999-999");
        $(".nu_inscricao_estadual").mask("9999999999999");
        $(".nu_telefone").mask("(99) 9999-9999");
        $(".nu_celular").mask("(99) 9999-9999?9");
        $(".ds_cns").mask("999999999999999");
        $("#nu_cns").mask("999999999999999");
        $(".nu_agencia").mask("9999");
        $(".nu_agenciaBrb").mask("9999");
        $(".nu_conta").mask("9999999");
        $(".nu_codigo").mask("999999");
        $(".nu_angariador").mask("999999");
        $(".nu_equipe").mask("999999");

    });
    $(function () {
        $(".getNumber").keydown(function (event) {
            if (event.keyCode == 46 || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 27 || event.keyCode == 13 || (event.keyCode == 65 && event.ctrlKey === true) || (event.keyCode >= 35 && event.keyCode <= 39)) {
                return;
            } else {
                if (event.shiftKey || (event.keyCode < 48 || event.keyCode > 57) && (event.keyCode < 96 || event.keyCode > 105)) {
                    event.preventDefault();
                }
            }
        });
    });

    $(".alpha").keyup(function () {
        var valor = $(this).val().replace(/[^a-zA-Z]+ /gi, '');
        $(this).val(valor);
    });

    //Valida CNPJ
    $(".nu_cnpj").blur(function () {
        var cnpj = $(".nu_cnpj").val();
        cnpj = cnpj.replace(/[^0-9+\Ee]/g, '');
        if (cnpj == '') {
            alert('O campo de CNPJ é obrigatório!')
        }

        // Elimina CNPJs invalidos conhecidos
        if (cnpj == "00000000000000" ||
            cnpj == "11111111111111" ||
            cnpj == "22222222222222" ||
            cnpj == "33333333333333" ||
            cnpj == "44444444444444" ||
            cnpj == "55555555555555" ||
            cnpj == "66666666666666" ||
            cnpj == "77777777777777" ||
            cnpj == "88888888888888" ||
            cnpj == "99999999999999") {
            alert('Seu CNPJ n&atilde;o é valido, favor digitar novamente');
            $(".nu_cnpj").val('').focus();
            return false;
        }

        // Valida DVs
        tamanho = cnpj.length - 2
        numeros = cnpj.substring(0, tamanho);
        digitos = cnpj.substring(tamanho);
        soma = 0;
        pos = tamanho - 7;
        for (i = tamanho; i >= 1; i--) {
            soma += numeros.charAt(tamanho - i) * pos--;
            if (pos < 2)
                pos = 9;
        }
        resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
        if (resultado != digitos.charAt(0)) {
            alert('Seu CNPJ n&atilde;o é valido, favor digitar novamente');
            $(".nu_cnpj").val('').focus();
            return false;
        }

        tamanho = tamanho + 1;
        numeros = cnpj.substring(0, tamanho);
        soma = 0;
        pos = tamanho - 7;
        for (i = tamanho; i >= 1; i--) {
            soma += numeros.charAt(tamanho - i) * pos--;
            if (pos < 2)
                pos = 9;
        }
        resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
        if (resultado != digitos.charAt(1)) {
            alert('Seu CNPJ n&atilde;o é valido, favor digitar novamente');
            $(".nu_cnpj").val('').focus();
            return false;
        }

        return true;
    });

    //valida inscriç&atilde;o estadual
    $(".nu_inscricao_estadual").blur(function () {

        var ie = $(".nu_inscricao_estadual").val();
        ie = ie.replace(/[^0-9+\Ee]/g, '');
        if (ie == '') {
            alert('A Inscriç&atilde;o Estadual n&atilde;o é valido, favor digitar novamente');
        }

        // Elimina CNPJs invalidos conhecidos
        if (ie == "0000000000000" ||
            ie == "1111111111111" ||
            ie == "2222222222222" ||
            ie == "3333333333333" ||
            ie == "4444444444444" ||
            ie == "5555555555555" ||
            ie == "6666666666666" ||
            ie == "7777777777777" ||
            ie == "8888888888888" ||
            ie == "9999999999999") {
            alert('A Inscriç&atilde;o Estadual n&atilde;o é valido, favor digitar novamente');
            $(".nu_inscricao_estadual").val('').focus();
            return false;
        }
        return true;
    });


    //valida cep
    $(".nu_cep").blur(function () {
        var cep = $(".nu_cep").val();
        cep = cep.replace(/[^0-9+\Ee]/g, '');
        if (cep == '') {
            alert('Seu CEP n&atilde;o é valido, favor digitar novamente');
        }
        // Elimina CNPJs invalidos conhecidos
        if (cep == "00000000" ||
            cep == "11111111" ||
            cep == "22222222" ||
            cep == "33333333" ||
            cep == "44444444" ||
            cep == "55555555" ||
            cep == "66666666" ||
            cep == "77777777" ||
            cep == "88888888" ||
            cep == "99999999") {
            alert('Seu CEP n&atilde;o é valido, favor digitar novamente');
            $(".nu_cep").val('').focus();
            return false;
        }
        return true;
    });

    //valida tel
    $(".nu_telefone_resi").blur(function () {
        var tel = $(".nu_telefone_resi").val();
        tel = tel.replace(/[^0-9+\Ee]/g, '');
        if (tel == '') {
            alert('Seu número de telefone n&atilde;o é valido, favor digitar novamente');
        }
        // Elimina CNPJs invalidos conhecidos
        if (tel == "0000000000" ||
            tel == "1111111111" ||
            tel == "2222222222" ||
            tel == "3333333333" ||
            tel == "4444444444" ||
            tel == "5555555555" ||
            tel == "6666666666" ||
            tel == "7777777777" ||
            tel == "8888888888" ||
            tel == "9999999999") {
            alert('Seu número de telefone n&atilde;o é valido, favor digitar novamente');
            $(".nu_telefone_resi").val('').focus();
            return false;
        }
        return true;
    });
    $(".nu_telefone_cel").blur(function () {
        var tel = $(".nu_telefone_cel").val();
        tel = tel.replace(/[^0-9+\Ee]/g, '');
        if (tel == '') {
            alert('Seu número de telefone n&atilde;o é valido, favor digitar novamente');
        }
        // Elimina CNPJs invalidos conhecidos
        if (tel == "0000000000" ||
            tel == "1111111111" ||
            tel == "2222222222" ||
            tel == "3333333333" ||
            tel == "4444444444" ||
            tel == "5555555555" ||
            tel == "6666666666" ||
            tel == "7777777777" ||
            tel == "8888888888" ||
            tel == "9999999999") {
            alert('Seu número de telefone n&atilde;o é valido, favor digitar novamente');
            $(".nu_telefone_cel").val('').focus();
            return false;
        }
        return true;
    });


    $(".nu_cpf").blur(function () {
        var cpf = $(".nu_cpf").val();
        cpf = cpf.replace(/[^\d]+/g, '');
        if (cpf == '')
            return false;
        // Elimina CPFs invalidos conhecidos
        if (cpf.length != 11 ||
            cpf == "00000000000" ||
            cpf == "11111111111" ||
            cpf == "22222222222" ||
            cpf == "33333333333" ||
            cpf == "44444444444" ||
            cpf == "55555555555" ||
            cpf == "66666666666" ||
            cpf == "77777777777" ||
            cpf == "88888888888" ||
            cpf == "99999999999") {
            alert('O CPF digitado n&atilde;o e valido, favor digitar novamente.');
            $(".nu_cpf").val('').focus();
        }

        // Valida 1o digito
        add = 0;
        for (i = 0; i < 9; i++)
            add += parseInt(cpf.charAt(i)) * (10 - i);
        rev = 11 - (add % 11);
        if (rev == 10 || rev == 11)
            rev = 0;
        if (rev != parseInt(cpf.charAt(9))) {
            alert('O CPF digitado n&atilde;o e valido, favor digitar novamente.');
            $(".nu_cpf").val('').focus();
        }
        // Valida 2o digito
        add = 0;
        for (i = 0; i < 10; i++)
            add += parseInt(cpf.charAt(i)) * (11 - i);
        rev = 11 - (add % 11);
        if (rev == 10 || rev == 11)
            rev = 0;
        if (rev != parseInt(cpf.charAt(10))) {
            alert('O CPF digitado n&atilde;o e valido, favor digitar novamente.');
            $(".nu_cpf").val('').focus();
        }
        return true;
    });

    $(".nu_cpfDep").blur(function () {
        var cpf = $(".nu_cpfDep").val();
        cpf = cpf.replace(/[^\d]+/g, '');
        if (cpf == '')
            return false;
        // Elimina CPFs invalidos conhecidos
        if (cpf.length != 11 ||
            cpf == "00000000000" ||
            cpf == "11111111111" ||
            cpf == "22222222222" ||
            cpf == "33333333333" ||
            cpf == "44444444444" ||
            cpf == "55555555555" ||
            cpf == "66666666666" ||
            cpf == "77777777777" ||
            cpf == "88888888888" ||
            cpf == "99999999999") {
            alert('O CPF digitado n&atilde;o e valido, favor digitar novamente.');
            $(".nu_cpfDep").val('').focus();
        }

        // Valida 1o digito
        add = 0;
        for (i = 0; i < 9; i++)
            add += parseInt(cpf.charAt(i)) * (10 - i);
        rev = 11 - (add % 11);
        if (rev == 10 || rev == 11)
            rev = 0;
        if (rev != parseInt(cpf.charAt(9))) {
            alert('O CPF digitado n&atilde;o e valido, favor digitar novamente.');
            $(".nu_cpfDep").val('').focus();
        }
        // Valida 2o digito
        add = 0;
        for (i = 0; i < 10; i++)
            add += parseInt(cpf.charAt(i)) * (11 - i);
        rev = 11 - (add % 11);
        if (rev == 10 || rev == 11)
            rev = 0;
        if (rev != parseInt(cpf.charAt(10))) {
            alert('O CPF digitado n&atilde;o e valido, favor digitar novamente.');
            $(".nu_cpfDep").val('').focus();
        }
        return true;
    });

    $(".nu_cep_endereco").keyup(
        function () {
            var val = $(".nu_cep_endereco").val().replace('_', '');
            if (val.length == 10) {
                val = val.replace('.', '');
                val = val.replace('-', '');
                consultacep(val);
            }

        });

    $("form").submit(
        function () {
            var parar = false;
            $(this).find("input:visible,select:visible,radio:visible,check:visible").each(
                function () {
                    if ($(this).attr("required") == "required" && $(this).val() == "") {
                        parar = true;
                        alert("Por Favor Preencher o campo " + $(this).closest("div").find("label").text().replace(":", "") + ".");
                        return false;
                    }

                }
            );

            if (parar) {
                return false;
            }

        }
    );
});


function Apenas_Numeros(caracter) {
    var nTecla = 0;
    if (document.all) {
        nTecla = caracter.keyCode;
    } else {
        nTecla = caracter.which;
    }
    if ((nTecla > 47 && nTecla < 58)
        || nTecla == 8 || nTecla == 127
        || nTecla == 0 || nTecla == 9  // 0 == Tab
        || nTecla == 13) { // 13 == Enter
        return true;
    } else {
        return false;
    }
}

function FormataCnpj(campo, teclapres) {
    var tecla = teclapres.keyCode;
    var vr = new String(campo.value);
    vr = vr.replace(".", "");
    vr = vr.replace("/", "");
    vr = vr.replace("-", "");
    tam = vr.length + 1;
    if (tecla != 14) {
        if (tam == 3)
            campo.value = vr.substr(0, 2) + '.';
        if (tam == 6)
            campo.value = vr.substr(0, 2) + '.' + vr.substr(2, 5) + '.';
        if (tam == 10)
            campo.value = vr.substr(0, 2) + '.' + vr.substr(2, 3) + '.' + vr.substr(6, 3) + '/';
        if (tam == 15)
            campo.value = vr.substr(0, 2) + '.' + vr.substr(2, 3) + '.' + vr.substr(6, 3) + '/' + vr.substr(9, 4) + '-' + vr.substr(13, 2);
    }
}

function FormataCpf(campo, teclapres) {
    var tecla = teclapres.keyCode;
    var vr = new String(campo.value);
    vr = vr.replace(".", "");
    vr = vr.replace(".", "");
    vr = vr.replace("-", "");
    tam = vr.length + 1;
    if (tecla != 14) {
        if (tam == 3)
            campo.value = vr.substr(0, 2) + '.';
        if (tam == 6)
            campo.value = vr.substr(0, 2) + '.' + vr.substr(2, 5) + '.';
        if (tam == 10)
            campo.value = vr.substr(0, 2) + '.' + vr.substr(2, 3) + '.' + vr.substr(6, 3) + '-';
        if (tam == 15)
            campo.value = vr.substr(0, 2) + '.' + vr.substr(2, 3) + '.' + vr.substr(6, 3) + '-' + vr.substr(9, 4);
    }
}

function FormataCep(campo, teclapres) {
    var tecla = teclapres.keyCode;
    var vr = new String(campo.value);
    vr = vr.replace(".", "");
    vr = vr.replace("/", "");
    vr = vr.replace("-", "");
    tam = vr.length + 1;
    if (tecla != 8) {
        if (tam == 3)
            campo.value = vr.substr(0, 2) + '.';
        if (tam == 5)
            campo.value = vr.substr(0, 2) + '.' + vr.substr(2, 3);
        if (tam == 6)
            campo.value = vr.substr(0, 2) + '.' + vr.substr(2, 3) + '-' + vr.substr(5, 8);
    }
}

function FormataTel(campo, teclapres) {
    var tecla = teclapres.keyCode;
    var vr = new String(campo.value);
    vr = vr.replace("(", "");
    vr = vr.replace(")", "");
    vr = vr.replace(" ", "");
    vr = vr.replace("-", "");
    tam = vr.length + 1;
    if (tecla != 8) {
        if (tam == 2)
            campo.value = '(' + vr.substr(0, 2);
        if (tam == 5)
            campo.value = '(' + vr.substr(0, 2) + ') ' + vr.substr(2, 6) + '-';
        if (tam == 7)
            campo.value = '(' + vr.substr(0, 2) + ') ' + vr.substr(2, 5) + '-' + vr.substr(6, 9);
    }
}

function FormataData(campo, teclapres) {
    var tecla = teclapres.keyCode;
    var vr = new String(campo.value);
    vr = vr.replace("(", "");
    vr = vr.replace(")", "");
    vr = vr.replace(" ", "");
    vr = vr.replace("-", "");
    tam = vr.length + 1;
    if (tecla != 8) {
        if (tam == 2)
            campo.value = '(' + vr.substr(0, 2);
        if (tam == 5)
            campo.value = '(' + vr.substr(0, 2) + ') ' + vr.substr(2, 6) + '-';
        if (tam == 7)
            campo.value = '(' + vr.substr(0, 2) + ') ' + vr.substr(2, 5) + '-' + vr.substr(6, 9);
    }
}

//valida o CNPJ digitado
function ValidarCNPJ(ObjCnpj) {
    var cnpj = ObjCnpj.value;

    var valida = new Array(6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2);
    var dig1 = new Number;
    var dig2 = new Number;

    exp = /\.|\-|\//g
    //    cnpj = cnpj.toString().replace( exp, "" ); 
    cnpj = cnpj.replace(/\.|\-|\//g, "");

    var digito = new Number(eval(cnpj.charAt(12) + cnpj.charAt(13)));

    for (i = 0; i < valida.length; i++) {
        dig1 += (i > 0 ? (cnpj.charAt(i - 1) * valida[i]) : 0);
        dig2 += cnpj.charAt(i) * valida[i];
    }
    dig1 = (((dig1 % 11) < 2) ? 0 : (11 - (dig1 % 11)));
    dig2 = (((dig2 % 11) < 2) ? 0 : (11 - (dig2 % 11)));

    if (((dig1 * 10) + dig2) != digito)
        alert('CNPJ Incorreto, favor digite novamente!');
    return false;

}

//valida o CPF digitado
function ValidarCPF(Objcpf) {
    var cpf = Objcpf.value;
    exp = /\.|\-/g
    cpf = cpf.toString().replace(exp, "");
    var digitoDigitado = eval(cpf.charAt(9) + cpf.charAt(10));
    var soma1 = 0, soma2 = 0;
    var vlr = 11;

    for (i = 0; i < 9; i++) {
        soma1 += eval(cpf.charAt(i) * (vlr - 1));
        soma2 += eval(cpf.charAt(i) * vlr);
        vlr--;
    }
    soma1 = (((soma1 * 10) % 11) == 10 ? 0 : ((soma1 * 10) % 11));
    soma2 = (((soma2 + (2 * soma1)) * 10) % 11);

    var digitoGerado = (soma1 * 10) + soma2;
    if (digitoGerado != digitoDigitado)
        alert('CPF Invalido!');
}

$("#nu_cep").change(function () {
    var cep_code = $('#nu_cep').val();

    if (cep_code.length <= 0) {
        return false;
    }

});

function loadXMLDoc(cep) {
    $.get("http://apps.widenet.com.br/busca-cep/api/cep.json", {code: cep},
        function (result) {
            if (result.status != 1) {
                alert("Seu Cep não foi encontrado, favor preencher o endereço completo.");
            } else {
                // $("#ds_cep").val(result.code);
                $("#ds_endereco").val(result.address);
                $("#ds_cidade").val(result.city);
                $("#ds_bairro").val(result.district);
                $("*[data-state=" + result.state + "]").attr('selected', 'selected');

            }
        });
}


function consultacep(cep) {
    loadXMLDoc(cep);
}

function correiocontrolcep(valor) {
    if (valor.erro) {
        $(".nu_cep_endereco").val($(".nu_cep_endereco").val());
        alert('Cep não encontrado, digite o endereço para completar o cadastro.');
    }
    $("input[name='ds_endereco_endereco_']").val(valor.logradouro);
    $("input[name='nm_bairro_endereco_']").val(valor.bairro);
    $("select[name='nm_uf_endereco_']").val(valor.uf);
    $("input[name='nm_cidade_endereco_']").val(valor.localidade);
}



