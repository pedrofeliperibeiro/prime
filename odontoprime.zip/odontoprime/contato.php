<!DOCTYPE HTML>
<html lang="pt-BR">
    
<head>
        <title>BRB ODONTO</title>
        <meta charset="UTF-8">
        <!--<meta charset="ISO-8859-1">-->
        <!--<meta http-equiv="X-UA-Compatible" content="IE=8" />-->
        <!--<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />-->
        <!--<meta http-equiv="X-UA-Compatible" content="chrome=1" />-->
        <!--<meta http-equiv="X-UA-Compatible" content="IE=4EDGE" />-->
         <link rel="stylesheet" href="frontend/style.css" />
        <link rel="stylesheet" href="frontend/skins/red-blue/blue.css" id="colors" /> 
        <link rel="icon" href="favicon.html" type="image/x-icon"/>
        <link rel="shortcut icon" href="frontend/favicon.html" type="image/x-icon"/>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.css" />
        <link rel="stylesheet" href="frontend/css/switcher.css">  
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
        <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.3.5/css/swiper.min.css'>
        <link rel="stylesheet" href="frontend/css/slider_odonto.css"> 

        <!--switcher and-->
    </head>
    <body>
        <div id="wrapper">
            <header id="header" class="container-fluid">
    <div class="header-bg">
        <div class="container">
            <div class="decoration dec-left visible-desktop"></div>
            <div class="decoration dec-right visible-desktop"></div>	 
            <?php include('menu.php');?> 
        </div>
    </div>
</header>
<section id="content" class="container-fluid">
    <div class="container">
        <div id="headline-page">
            <h1>Contato</h1>
           
        </div>
        
        <div class="row">
            <div class="span8">
                <div class="title"><h2>Comunicaç&atilde;o é essencial</h2></div>
                <p>
                    A Ouvidoria é um dos canais de comunicaç&atilde;o responsável por receber e dar encaminhamento às sugestões, elogios, dúvidas ou críticas relacionadas aos serviços prestados pela odontoprime. A Ouvidoria deve ser acionada sempre que os demais canais de comunicaç&atilde;o disponíveis se mostrarem insuficientes.
                </p>
                                <form id="ajax-contact-form" method="post" action="http://www.odontoprime.com/contato">
                    <div class="row">
                        <div class="span4">
                            <div class="form-padding">
                                <label for="f1">Nome:</label>
                                <input type="text" tabindex="1" name="nome" id="f1" class="form-text" value="">
                                <label for="f4">Assunto:</label>
                                <input type="text" tabindex="3" name="assunto" id="f4" class="form-text" value="" size="40">
                            </div>
                        </div>
                        <div class="span4">
                            <div class="form-padding">
                                <label for="f3">Email:</label>
                                <input type="text" tabindex="2" name="email" id="f3" class="form-text" value="" size="40">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="span8">
                            <div class="form-padding">
                                <label for="f5">Mensagem:</label>
                                <textarea name="mensagem" tabindex="4" id="f5" cols="40" rows="10"></textarea>	
                                <input type="submit" class="button s1 small" value="Enviar">
                            </div>
                        </div>
                    </div>				
                </form>
                            </div>
            <div class="span4">
                <div class="headline"><h4>Endereço</h4></div>
                <div class="card">
                    <!-- <span class="contact-line c1">Setor de Autarquias Sul, Quadra 04,</span>
                    <span class="contact-line c1">Edifício Victoria Office Tower,</span>
                    <span class="contact-line c1">Salas 1101/1112, 11º Andar</span>
                    <span class="contact-line c2">Telefone: <a href="#call">(61) 3421-0000 para Brasilia ou 4007-1087</a></span> -->
                    <span class="contact-line c3">E-mail: <a href="mailto:contato@odontoprime.com.br<">contato@odontoprime.com.br</a></span>
                </div>
                <div class="headline"><h4>Redes Sociais</h4></div>
<ul class="social-icons">
    <li class="facebook"><a href="#">Facebook</a></li>
    <li class="twitter"><a href="#">Twitter</a></li>
    <li class="linkedin"><a href="#">LinkedIn</a></li>
    <li class="googleplus"><a href="#">GooglePlus</a></li>
    <li class="youtube"><a href="#">youtube</a></li>
    <li class="rss"><a href="#">Rss</a></li>
</ul>            </div>
        </div>
    </div>
</section>        </div>
        <?php include('footer.php'); ?>

  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
  <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
  <script src="frontend/js/bootstrap.min.js"></script>
  <!--<script src="/frontend/js/json.js"></script>-->
  <script src="frontend/js/jquery.color.js"></script>
  <!--[if IE]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
  <script src="frontend/js/jquery-easing-1.3.js" type="text/javascript"></script>
  <script src="frontend/js/layerslider.kreaturamedia.jquery.js" type="text/javascript"></script>
  <!--<script src="//cdnjs.cloudflare.com/ajax/libs/json3/3.3.2/json3.min.js"></script>-->
  <script src="frontend/js/custom.js"></script>
  <!--switcher-->

  <script src="frontend/js/jquery.cookie.js"></script>

  <script src="frontend/js/switcher.js"></script>
  <script src="frontend/js/jquery.maskedinput.js"></script>
  <script src="frontend/js/valida.js"></script>
  <!--switcher and-->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.3.5/js/swiper.min.js'></script>
  <script type="text/javascript">
    function carregaPage(){

    }

  </script>
    </body>

</html>
