<!DOCTYPE HTML>
<html lang="pt-BR">
    
<head>
        <title>OdontoPrime</title>
        <meta charset="UTF-8">
        <!--<meta charset="ISO-8859-1">-->
        <!--<meta http-equiv="X-UA-Compatible" content="IE=8" />-->
        <!--<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />-->
        <!--<meta http-equiv="X-UA-Compatible" content="chrome=1" />-->
        <!--<meta http-equiv="X-UA-Compatible" content="IE=4EDGE" />-->
        <link rel="stylesheet" href="frontend/style.css" />
        <link rel="stylesheet" href="frontend/skins/red-blue/blue.css" id="colors" /> 
        <link rel="icon" href="favicon.html" type="image/x-icon"/>
        <link rel="shortcut icon" href="frontend/favicon.html" type="image/x-icon"/>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.css" />
        <link rel="stylesheet" href="frontend/css/switcher.css">  
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
        <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.3.5/css/swiper.min.css'>
        <link rel="stylesheet" href="frontend/css/slider_odonto.css">  

        <!--switcher and-->
    </head>
    <body>
        <div id="wrapper">
            <script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false"></script>
<script type="text/javascript" src="frontend/js/mapa.js"></script>
<script type="text/javascript" src="frontend/js/jquery-ui.custom.min.js"></script>
<header id="header" class="container-fluid">
    <div class="header-bg">
        <div class="container">
            <div class="decoration dec-left visible-desktop"></div>
            <div class="decoration dec-right visible-desktop"></div>	  
          <?php include('menu.php'); ?>
        </div>
    </div>
</header>
<section id="content" class="container-fluid">
    <div class="container">
        <div id="headline-page">
            <h1>Rede Credenciada</h1>
            
        </div>

        <div class="row">
            <div class="span10">
                <div class="title"><h2>Rede Credenciada</h2></div>
                <form method="post">
                    <div class="row">
                        <iframe id="odonto_iframe" name="odonto_iframe" class="odonto_iframe" width="125%" height="600" src="http://odontoprime.s4e.com.br/SYS/rede_atendimento/rede_atendimento.aspx?modal=1" frameborder="0"></iframe>


                    </div>
                </form>
            </div>

        </div>
    </div>
</section>

<script type="text/javascript">
    var url = '/rede/dados';
    var consulta = '/rede/consulta';
</script>        
</div>
  <?php include('footer.php'); ?>

  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
  <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
  <script src="frontend/js/bootstrap.min.js"></script>
  <!--<script src="/frontend/js/json.js"></script>-->
  <script src="frontend/js/jquery.color.js"></script>
  <!--[if IE]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
  <script src="frontend/js/jquery-easing-1.3.js" type="text/javascript"></script>
  <script src="frontend/js/layerslider.kreaturamedia.jquery.js" type="text/javascript"></script>
  <!--<script src="//cdnjs.cloudflare.com/ajax/libs/json3/3.3.2/json3.min.js"></script>-->
  <script src="frontend/js/custom.js"></script>
  <!--switcher-->

  <script src="frontend/js/jquery.cookie.js"></script>

  <script src="frontend/js/switcher.js"></script>
  <script src="frontend/js/jquery.maskedinput.js"></script>
  <script src="frontend/js/valida.js"></script>
  <!--switcher and-->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.3.5/js/swiper.min.js'></script>
  <script type="text/javascript">
    function carregaPage(){

    }

  </script>
    </body>

</html>
