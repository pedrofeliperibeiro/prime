<!DOCTYPE HTML>
<html lang="pt-BR">

<head>
    <title>OdontoPrime</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,user-scalable=no"/>
    
    <link rel="stylesheet" href="frontend/style.css" />
    <link rel="stylesheet" href="frontend/skins/red-blue/blue.css" id="colors" /> 
    <link rel="icon" href="favicon.html" type="image/x-icon"/>
    <link rel="shortcut icon" href="frontend/favicon.html" type="image/x-icon"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.css" />
    <link rel="stylesheet" href="frontend/css/switcher.css">  
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.3.5/css/swiper.min.css'>
    <link rel="stylesheet" href="frontend/css/slider_odonto.css">  

    
</head>
<body onload="carregaPage()">
<div id="wrapper">
  <header id="header" class="container-fluid main">    
    <div class="header-bg" style="background:url(frontend/images/background2.jpg) no-repeat; background-size: cover; background-position: center; background-attachment: fixed;">
        <div class="container" >
            <?php include('menu.php'); ?>
         </div>            
  <div class="row" >
    <!-- slider -->
    <div class="carousel">
    <div class="carousel-inner">
        <input class="carousel-open" type="radio" id="carousel-1" name="carousel" aria-hidden="true" hidden="" checked="checked">
        <div class="carousel-item">
            <img src="frontend/images/banner.jpg">
        </div>
        <input class="carousel-open" type="radio" id="carousel-2" name="carousel" aria-hidden="true" hidden="">
        <div class="carousel-item">
            <img src="http://fakeimg.pl/2000x800/DA5930/fff/?text=JavaScript">
        </div>
        <input class="carousel-open" type="radio" id="carousel-3" name="carousel" aria-hidden="true" hidden="">
        <div class="carousel-item">
            <img src="http://fakeimg.pl/2000x800/F90/fff/?text=Carousel">
        </div>
        <label for="carousel-3" class="carousel-control prev control-1">‹</label>
        <label for="carousel-2" class="carousel-control next control-1">›</label>
        <label for="carousel-1" class="carousel-control prev control-2">‹</label>
        <label for="carousel-3" class="carousel-control next control-2">›</label>
        <label for="carousel-2" class="carousel-control prev control-3">‹</label>
        <label for="carousel-1" class="carousel-control next control-3">›</label>
        <ol class="carousel-indicators">
            <li>
                <label for="carousel-1" class="carousel-bullet">•</label>
            </li>
            <li>
                <label for="carousel-2" class="carousel-bullet">•</label>
            </li>
            <li>
                <label for="carousel-3" class="carousel-bullet">•</label>
            </li>
        </ol>
    </div>
</div>
    <!---------------->
  </div>
</header>
<section id="content" class="container-fluid mt-5" style="margin-top: 4vmin;">
    <div class="container">
        <div class="row">
            <div class="span9">
                <h1>OdontoPrime</h1>
                <span class="purchase">Pensando no bem estar e melhor qualidade de vida de seus correntistas, criamos a OdontoPrime. Em parceria firmada com as melhores operadoras de odontologia do país, s&atilde;o ofertados planos odontológicos de acordo com o perfil de cada cliente.</span>
            </div>
        </div>
        <div class="row">
            <div class="span12">
                <h1>Por que contratar?</h1>
                <div class="row">
                    <div class="span3">
                        <a href="#" class="link-block">
                            <span class="move-item icon-1 move-bg-icon" style="top: 0px;"></span>
                            <h2 class="move-item" style="left: 0px;">Emergência 24Hs</h2>
                            <p class="move-item" style="bottom: 0px;">
                                Pronto Atendimento 24h em clínicas de emergência. 
                            </p>
                        </a>
                    </div>
                    <div class="span3">
                        <a href="#" class="link-block">
                            <span class="move-item icon-2 move-bg-icon" style="top: 0px;"></span>
                            <h2 class="move-item" style="left: 0px;">Cobertura Nacional</h2>
                            <p class="move-item" style="bottom: 0px;">
                                Tranquilidade para você e sua família quando precisar de atendimento em outras cidades. 
                            </p>
                        </a>
                    </div>
                    <div class="span3">
                        <a href="#" class="link-block">
                            <span class="move-item icon-3 move-bg-icon" style="top: 0px;"></span>
                            <h2 class="move-item" style="left: 0px;">Plano sem carência</h2>
                            <p class="move-item" style="bottom: 0px;">
                                Planos sem carência para você começar a cuidar de sua saúde sem perder tempo. Consulte condições. 
                            </p>
                        </a>
                    </div>
                    <div class="span3">
                        <a href="#" class="link-block">
                            <span class="move-item icon-4 move-bg-icon" style="top: 0px;"></span>
                            <h2 class="move-item" style="left: 0px;">Ampla Cobertura</h2>
                            <p class="move-item" style="bottom: 0px;">
                                Todas as coberturas exigidas pela ANS e mais de 270 procedimentos adicionais. 
                            </p>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="span4">
                <div class="title"><h2>Envie um depoimento</h2></div>
                <p><i>Envie um depoimento à respeito da sua experiência com os nossos serviços.</i></p>
                <p>
                    <span class="phone contact">3421-0000 para Brasilia ou 4007-1087</span>
                    <a href="mailto:your@domein.com" class="email contact">contato@odontoprime.com.br</a>
                </p>
                <a href="#" class="button small s3">Formulário de Contato</a>
            </div>

            <div class="span8">
                <div class="title"><h2>Depoimentos dos nossos clientes:</h2></div>
                <div class="carousel slide review-slider" id="MeetOurDoctor4">
                    <div class="blockquote-line"><div class="blockquote-pattern"></div></div>
                    <div class="carousel-inner review-inner">
                        <div class="active item">
                            <div class="blockquote">
                                “Tem sempre uma clínica perto de mim. Nunca fiquei na m&atilde;o”.
                            </div>
                            <div class="md">
                                <img alt="" src="frontend/images/gallery/estudante.jpg"/>
                                <div class="md-name">
                                    <strong>Sandro René</strong>
                                    <div class="company-name">Estudante de Direito</div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="blockquote">
                            “Já precisei usar meu plano fora de Brasília e pra minha surpresa, foi bem fácil encontrar um dentista credenciado em outra cidade”.
                            </div>
                            <div class="md">
                                <img alt="" src="/frontend/images/gallery/editor.jpg"/>
                                <div class="md-name">
                                    <strong>Marcelo Araújo</strong>
                                    <div class="company-name">Editor de Vídeo</div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="blockquote">
                                “Sou beneficiário da odontoprime há 15 anos. Durante todo esse tempo, eu e minha família sempre fomos bem atendidos”.
                            </div>
                            <div class="md">
                                <img alt="" src="frontend/images/gallery/casal.jpg"/>
                                <div class="md-name">
                                    <strong>Lourival R. da Costa</strong>
                                    <div class="company-name">Servidor Público Federal</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <a class="prew-slide nav-slider" href="#MeetOurDoctor4" data-slide="prev">&lsaquo;</a>
                    <a class="next-slide nav-slider" href="#MeetOurDoctor4" data-slide="next">&rsaquo;</a>
                </div>							
            </div>	
        </div>
    </div>
</section>        
</div>
<?php include('footer.php'); ?>
  
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
  <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
  <script src="frontend/js/bootstrap.min.js"></script>
  <!--<script src="/frontend/js/json.js"></script>-->
  <script src="frontend/js/jquery.color.js"></script>
  <!--[if IE]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
  <script src="frontend/js/jquery-easing-1.3.js" type="text/javascript"></script>
  <script src="frontend/js/layerslider.kreaturamedia.jquery.js" type="text/javascript"></script>
  <!--<script src="//cdnjs.cloudflare.com/ajax/libs/json3/3.3.2/json3.min.js"></script>-->
  <script src="frontend/js/custom.js"></script>
  <!--switcher-->
  
  <script src="frontend/js/jquery.cookie.js"></script>

  <script src="frontend/js/switcher.js"></script>
  <script src="frontend/js/jquery.maskedinput.js"></script>
  <script src="frontend/js/valida.js"></script>
  <!--switcher and-->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.3.5/js/swiper.min.js'></script>
  <script type="text/javascript">
  function carregaPage(){
    
  }
 
  </script>


  </body>
</html>
